const fs = require('fs');
const ARCHIVO = './tareas.json';

// Si no existe el archivo, lo creamos vacío
if (!fs.existsSync(ARCHIVO)) {
    fs.writeFileSync(ARCHIVO, '[]');
}

function leerTareas() {
    const datos = fs.readFileSync(ARCHIVO, 'utf-8');
    return JSON.parse(datos);
}

function guardarTareas(tareas) {
    fs.writeFileSync(ARCHIVO, JSON.stringify(tareas, null, 2));
}

module.exports = { leerTareas, guardarTareas };