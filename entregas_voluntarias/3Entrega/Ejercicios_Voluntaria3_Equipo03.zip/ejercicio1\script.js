const botonMic      = document.getElementById('botonMic');
const textoEstado   = document.getElementById('textoEstado');
const transcripcion = document.getElementById('transcripcion');
const tarjetaClima  = document.getElementById('tarjetaClima');
const tarjetaError  = document.getElementById('tarjetaError');
const loader        = document.getElementById('loader');


const codigosClima = {
  0:  'Cielo despejado ☀️',
  1:  'Mayormente despejado 🌤️',
  2:  'Parcialmente nublado ⛅',
  3:  'Nublado ☁️',
  45: 'Niebla 🌫️',
  48: 'Niebla con escarcha 🌫️',
  51: 'Llovizna ligera 🌦️',
  53: 'Llovizna moderada 🌦️',
  55: 'Llovizna densa 🌧️',
  61: 'Lluvia ligera 🌧️',
  63: 'Lluvia moderada 🌧️',
  65: 'Lluvia intensa 🌧️',
  71: 'Nieve ligera ❄️',
  73: 'Nieve moderada ❄️',
  75: 'Nieve intensa ❄️',
  80: 'Chubascos ligeros 🌦️',
  81: 'Chubascos moderados 🌧️',
  82: 'Chubascos violentos ⛈️',
  95: 'Tormenta eléctrica ⛈️',
  99: 'Tormenta con granizo ⛈️🌨️',
};

// estado de la interfaz
function mostrarEstado(mensaje, tipo = '') {
  textoEstado.textContent = mensaje;
  textoEstado.className = 'texto-estado ' + tipo;
}

function mostrarError(mensaje) {
  tarjetaError.textContent = '⚠️ ' + mensaje;
  tarjetaError.className = 'tarjeta-error';
  tarjetaClima.className = 'tarjeta-clima oculto';
  loader.className = 'loader-oculto';
}

function ocultarError() {
  tarjetaError.className = 'tarjeta-error oculto';
}

function mostrarLoader() {
  loader.className = 'loader-visible';
}

function ocultarLoader() {
  loader.className = 'loader-oculto';
}

// geolocalización
function obtenerPosicion() {
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) {
      reject(new Error('Tu navegador no soporta geolocalización.'));
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (posicion) => {
        resolve({
          lat: posicion.coords.latitude,
          lon: posicion.coords.longitude,
        });
      },
      (error) => {
        const mensajes = {
          1: 'Permiso de ubicación denegado. Actívalo en el navegador.',
          2: 'Ubicación no disponible en este momento.',
          3: 'Tiempo de espera de ubicación agotado.',
        };
        reject(new Error(mensajes[error.code] || 'Error desconocido al obtener ubicación.'));
      },
      { timeout: 15000, enableHighAccuracy: false, maximumAge: 60000 }
    );
  });
}

// peticion de fetch
async function pedirClima(lat, lon) {
  const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current_weather=true`;
  const respuesta = await fetch(url);
  if (!respuesta.ok) {
    throw new Error(`Error de API: ${respuesta.status} ${respuesta.statusText}`);
  }
  const datos = await respuesta.json();
  if (!datos.current_weather) {
    throw new Error('La API no devolvió datos de clima actual.');
  }
  return datos;
}

// mostrar datos en pantalla
function pintarClima(datos, lat, lon) {
  const climaActual = datos.current_weather;
  const descripcion = codigosClima[climaActual.weathercode] || `Código ${climaActual.weathercode}`;

  document.getElementById('climaTemp').textContent      = `${climaActual.temperature}°C`;
  document.getElementById('climaDesc').textContent      = descripcion;
  document.getElementById('climaViento').textContent    = `${climaActual.windspeed} km/h`;
  document.getElementById('climaDireccion').textContent = `${climaActual.winddirection}°`;
  document.getElementById('climaLat').textContent       = lat.toFixed(4);
  document.getElementById('climaLon').textContent       = lon.toFixed(4);
  document.getElementById('climaUbicacion').textContent = `📍 ${lat.toFixed(3)}, ${lon.toFixed(3)}`;
  document.getElementById('climaHora').textContent      = new Date().toLocaleTimeString('es-ES', {
    hour: '2-digit', minute: '2-digit',
  });

  tarjetaClima.className = 'tarjeta-clima';
  ocultarLoader();
}

// flujo principal
async function consultarClima() {
  ocultarError();
  tarjetaClima.className = 'tarjeta-clima oculto';
  mostrarLoader();
  mostrarEstado('Obteniendo tu ubicación GPS…', 'activo');

  try {
    const { lat, lon } = await obtenerPosicion();
    mostrarEstado(`📍 ${lat.toFixed(3)}, ${lon.toFixed(3)} — Consultando API…`, 'activo');

    const datos = await pedirClima(lat, lon);

    mostrarEstado('✅ Clima obtenido correctamente', 'activo');
    pintarClima(datos, lat, lon);

  } catch (error) {
    mostrarError(error.message);
    mostrarEstado('Error al obtener el clima', 'error');
    console.error('[ClimaPorVoz]', error);
  }
}

// reconocimiento de voz
const ReconocimientoVoz = window.SpeechRecognition || window.webkitSpeechRecognition;

if (!ReconocimientoVoz) {
  mostrarEstado('⚠️ Tu navegador no soporta reconocimiento de voz (usa Chrome)', 'error');
  botonMic.disabled = true;
  botonMic.style.opacity = '0.4';

} else {

  const reconocedor = new ReconocimientoVoz();
  reconocedor.lang = 'es-ES';
  reconocedor.continuous = false;
  reconocedor.interimResults = false;

  let estaEscuchando = false;

  const palabrasClave = ['clima', 'temperatura', 'tiempo', 'calor', 'frío', 'lluvia', 'weather'];

  botonMic.addEventListener('click', () => {
    if (estaEscuchando) { reconocedor.stop(); return; }
    reconocedor.start();
  });

  reconocedor.onstart = () => {
    estaEscuchando = true;
    botonMic.classList.add('escuchando');
    botonMic.querySelector('.icono-mic').textContent = '⏹';
    mostrarEstado('🎤 Escuchando… Habla ahora', 'activo');
    transcripcion.textContent = '…';
    transcripcion.className = 'caja-transcripcion';
  };

  reconocedor.onresult = (evento) => {
    const textoOido = evento.results[0][0].transcript.toLowerCase();
    transcripcion.textContent = `"${evento.results[0][0].transcript}"`;
    transcripcion.className = 'caja-transcripcion con-contenido';
    mostrarEstado(`Entendí: "${textoOido}"`, 'activo');

    const hayCoincidencia = palabrasClave.some(palabra => textoOido.includes(palabra));
    if (hayCoincidencia) {
      consultarClima();
    } else {
      mostrarEstado('No reconocí una pregunta sobre el clima. Intenta de nuevo.', 'error');
    }
  };

  reconocedor.onerror = (evento) => {
    const erroresVoz = {
      'no-speech':     'No se detectó voz. Intenta de nuevo.',
      'audio-capture': 'No se detectó micrófono en tu dispositivo.',
      'not-allowed':   'Permiso de micrófono denegado. Actívalo en el navegador.',
      'network':       'Error de red durante el reconocimiento de voz.',
      'aborted':       'Reconocimiento cancelado.',
    };
    mostrarEstado(erroresVoz[evento.error] || `Error de voz: ${evento.error}`, 'error');
  };

  reconocedor.onend = () => {
    estaEscuchando = false;
    botonMic.classList.remove('escuchando');
    botonMic.querySelector('.icono-mic').textContent = '🎙';
  };
}